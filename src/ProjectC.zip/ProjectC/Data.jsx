import Dog from "../images/dog.jpg"
import Dog1 from '../images/dog1.jpg';
import Dog2 from '../images/dog2.jpg'

const Data =[
    {
        img:`${Dog}`, 
        alt:"First slide",
         heading:"Dr. Priyank Vyas Pet Hospital & Diagnostic Centre dog clinic and veterinary services" ,
         para:"Nulla vitae elit libero, a pharetra augue mollis interdum."
    },
    {
        img:`${Dog1}`, 
        alt:"Second slide",
         heading:"Dr. Priyank Vyas Pet Hospital & Diagnostic Centre dog clinic and veterinary services" ,
         para:"Nulla vitae elit libero, a pharetra augue mollis ."
    },
    {
        img:`${Dog2}`, 
        alt:"Third slide",
         heading:"Dr. Priyank Vyas Pet Hospital & Diagnostic Centre dog clinic and veterinary services" ,
         para:"Nulla vitae elit libero, a pharetra augue mollis ."
    },
  
]

const IconData= [
    {
        icn:"whatsapp fab fa-whatsapp-square"
    },
    {
        icn:"envelope fas fa-envelope-square"
    },{
        icn:"phone fas fa-phone"
    }
]


const OurClinicData= [
    {
        heading:"Our Clinic",
        para:"Dr. Priyank Vya Pet Hospital & Diagnostic Centre dog clinic and veterinary services has its place in the list of Veterinary Clinics. Organization has an average score of 4 by NiceLocal visitors and concludes its business by the following address: Dehradun, Uttarakhand 248001, opposite Sakti Medicos, Subhash Nagar, Tilak Marg. GPS coordinates are: longitude — 77°59'28.99''E (77.991387), latitude — 30°16'38.15''N (30.277264)."
    }
]

const ClinicData=[
    {
        img:"https://picsum.photos/200/300",
        button:"Pet Of Month",
        para:"It was with a very heavy heart that Lazy’s owner had to relocate and could not take her with him. True to her name, she is very easy-going and loves to lounge around all day. She likes atte",
        link:"Read more..."
    },
    {
        img:"https://picsum.photos/200/300",
        button:"Hot Deals",
        para:"It was with a very heavy herue to her name, she is very easy-going and loves to lounge around all day. She likes atte",
        link:"Read more..."
    },
    {
        img:"https://picsum.photos/200/300",
        button:"Video Of Month",
        para:"It was with a very heavy heart that Lazy’s owner had to relocate and could not take her with him. True to her name, she is very easy-going and loves to lounge around all day. She likes atte",
        link:"Read more..."
    }
]

export default Data;
export {IconData, OurClinicData,ClinicData};