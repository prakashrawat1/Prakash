import React from 'react';
import Nav1 from './Nav1';
import Cara from './Cara';
import { IconsRepeat } from './Icons';
// import { CardsRepeat } from './ClinicCards';
import OurClinic from './OurClinic';
import{OurClinicData}  from './Data'

const Main = () =>{
return(

<>

<Nav1/>
<Cara/>
<IconsRepeat/>
<OurClinic heading={OurClinicData[0].heading} para={OurClinicData[0].para}/>

</>

);

};

export default Main;